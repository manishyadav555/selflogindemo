package tech.itsatr.login.dao;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import tech.itsatr.login.bean.LoginBean;

public class LoginDao {

	private String dbUrl = "jdbc:mysql://localhost:3306/userdb";
	private String dbUname ="root";
	private String dbpassword ="root";
	private String dbDriver ="com.mysql.cj.jdbc.Driver";
	
	public void loadDriver(String dbDriver)
	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
     public Connection getConnection()
     {
    	 Connection con = null;
    	 try {
			con= DriverManager.getConnection(dbUrl, dbUname, dbpassword);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
    	 return con;
     }
	
	
	public boolean validate(LoginBean loginbean) {
		boolean status = false;
		loadDriver(dbDriver);
		Connection con = getConnection();
		
		String sql = "select * from login where username = ? and password =?";
		
		PreparedStatement ps;
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, loginbean.getUsername());
			ps.setString(2, loginbean.getPassword());
			
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
		
	}
	
	
}
